import 'package:flutter/material.dart';
import '../home_page.dart';
import '../qrscanner.dart';
//import 'fingerprint_page.dart';
import 'package:flutter/cupertino.dart';
//import 'qrscanner.dart';

class Navbar extends StatelessWidget {
  const Navbar({super.key});

  @override
  Widget build(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.qr_code_scanner),
            label: 'Scan',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
        ],
      ),
      tabBuilder: (context, index) {
        late final CupertinoTabView returnValue;
        switch (index) {
          case 0:
          /* returnValue = CupertinoTabView(builder: (context) {
              return Scaffold(
                //child: ProductListTab(),
              );
            });*/
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => HomePage()),
            );
            break;
          case 1:
          /*returnValue = CupertinoTabView(builder: (context) {
              return CupertinoPageScaffold(
               child: QrCodeScanner(),
              );*/
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (context) => QrCodeScanner()),
            );
            //});
            break;
          case 2:
            returnValue = CupertinoTabView(builder: (context) {
              return Scaffold(
                //child: ShoppingCartTab(),
              );
            });
            break;
        }
        return returnValue;
      },
    );
  }
}