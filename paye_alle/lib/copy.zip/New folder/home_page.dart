import 'package:flutter/material.dart';
import 'api/navbar.dart';
import 'fingerprint_page.dart';
//import 'package:flutter/cupertino.dart';
//import 'qrscanner.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff388e3c),
        title: Text('PayeAlle'),
        titleTextStyle: TextStyle(
            fontSize: 25, fontWeight: FontWeight.w500,
        ),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Log out',
            onPressed: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => FingerprintPage()),
              );
            },
          ), //IconButton
        ],
        toolbarHeight: 65,
      ),
      body: Center(
        //child: Text('Welcome to the home page!'),
        child:
          Container(child: Navbar()),
      ),
    );
  }
}
